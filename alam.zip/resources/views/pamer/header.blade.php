<!DOCTYPE html>
<html>
<head>
</head>
<link rel="stylesheet" href="css/home.css">
<body>
    <!-- Isi halaman Anda di sini -->

<div class="header-fluid p-0">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ff5500" fill-opacity="0.55" d="M0,288L16,272C32,256,64,224,96,224C128,224,160,256,192,229.3C224,203,256,117,288,122.7C320,128,352,224,384,224C416,224,448,128,480,112C512,96,544,160,576,170.7C608,181,640,139,672,106.7C704,75,736,53,768,53.3C800,53,832,75,864,122.7C896,171,928,245,960,256C992,267,1024,213,1056,176C1088,139,1120,117,1152,117.3C1184,117,1216,139,1248,122.7C1280,107,1312,53,1344,58.7C1376,64,1408,128,1424,160L1440,192L1440,0L1424,0C1408,0,1376,0,1344,0C1312,0,1280,0,1248,0C1216,0,1184,0,1152,0C1120,0,1088,0,1056,0C1024,0,992,0,960,0C928,0,896,0,864,0C832,0,800,0,768,0C736,0,704,0,672,0C640,0,608,0,576,0C544,0,512,0,480,0C448,0,416,0,384,0C352,0,320,0,288,0C256,0,224,0,192,0C160,0,128,0,96,0C64,0,32,0,16,0L0,0Z"></path></svg>       
    <div class="header-content">
        <div class="header-image">
            <img src="/img/image 8.png" alt="">
        </div>
        <div class="header-text">
            <p class="text-over-shapes">Temukan <span>kelembutan</span> dan <span>kelezatan</span> autentik dari kue pancong</p>
            <p class="text-over-shapes1">Aroma dari kue pancong dan kelembutannya mengajak jiwa untuk memulai petualangan rasa dalam setiap suapan</p>
            <a href="#kategori" class="btn btn-outline-dark">Beli Sekarang</a>
        </div>
    </div>
</div>

</body>
</html>
