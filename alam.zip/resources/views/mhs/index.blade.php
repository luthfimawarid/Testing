<!DOCTYPE html>
<html lang="en">
<head>
    <title>WebSaya.Com</title>
</head>
<body>
    <h1>Selamat Datang {{ isset($mhs) ? $mhs : 'Tidak ada' }} di WebSaya.Com</h1>
</body>
</html>