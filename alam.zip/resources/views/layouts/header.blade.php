<div class="alert alert-primary mb-0" role="alert">
    <div class="container">
        <h1>WebSaya.Com</h1>
    </div>
</div>