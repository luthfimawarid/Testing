<div class="container" style="text-align: center;">
    Copyright 2022 - websaya.com
</div><?php /**PATH C:\Users\ninas\OneDrive\Documents\KULIAH 2022-2025\semester 3\PROYEK 2\pancong\resources\views/layouts/footer.blade.php ENDPATH**/ ?>