
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('stylesheets'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/pancong.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1><?php echo e($deskripsi); ?></h1>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css"> 
    <div class="deskripsi">
        <div class="container text-center">
            <div class="row">
                <div class="col">
                    <img src="img/Group 52.png" alt="Group 52">
                </div>
                <div class="col text-start">
                    <p>Chocolate chruncy</p>
                    <i class="bi bi-dot">Oreo 2k</i>
                    <i class="bi bi-dot">Milo 2k</i>
                    <i class="bi bi-dot">Keju 2k</i>
                    <i class="bi bi-dot">Meises 2k</i>
                    <i class="bi bi-dot">Kacang 2k</i>
                    <!-- Update your buttons -->
                    <button class="outline-btn" onclick="showToppingModal()">Masukkan Keranjang</button>
                    <button class="outline-btn" onclick="showToppingModal()">Beli Sekarang</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
   <!-- Add this modal structure at the end of your HTML body -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class=" modal-content">
      <div class="potop modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Pilih Topping</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="pobo modal-body">
    <!-- Add your topping options here -->
    <div class="topping-option">
        <label><input type="checkbox" value="Oreo"> Oreo</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Milo"> Milo</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Keju"> Keju</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Susu"> Susu</label>
    </div>
    <div class="topping-option">
      <label><input type="checkbox" value="Red Velvet"> Red Velvet</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Kacang Almond"> Kacang Almond</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Meises"> Meises</label>
    </div>
    <div class="topping-option">
        <label><input type="checkbox" value="Choco Chips"> Choco Chips</label>
    </div>
    <!-- Add more topping options as needed -->
</div>

      <div class="potop modal-footer">
        <a href="/keranjang" type="button" class="btn btn-primary" onclick="tambahKeKeranjang()">Matang</a>
        <a href="/keranjang" type="button" class="btn btn-primary" onclick="tambahKeKeranjang()">Setengah Matang</a>
      </div>
    </div>
  </div>
</div>

    <script src="js/script.js"></script>
<!-- Add these scripts before your custom script -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
  function showToppingModal() {
    $('#myModal').modal('show');
  }

  function tambahKeKeranjang() {
    var selectedToppings = [];
    $('.topping-option input:checked').each(function() {
      selectedToppings.push($(this).val());
    });

    console.log('Selected Toppings:', selectedToppings);

    $('#myModal').modal('hide');
  }
</script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('pamer.main2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ninas\OneDrive\Documents\KULIAH 2022-2025\semester 3\PROYEK 2\pancong\resources\views/deskripsi/home.blade.php ENDPATH**/ ?>