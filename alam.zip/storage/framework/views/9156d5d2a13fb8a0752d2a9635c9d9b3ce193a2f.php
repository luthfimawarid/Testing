<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($slug === "home") ? 'active' : ''); ?>" aria-current="page"
                     href="/home">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($slug === "profil") ? 'active' : ''); ?>"
                     href="/profil">Profil</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($slug === "mahasiswa") ? 'active' : ''); ?>" 
                     href="/mahasiswa">Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(($slug === "prodi") ? 'active' : ''); ?>" 
                     href="/prodi">Prodi</a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\Users\ninas\OneDrive\Documents\KULIAH 2022-2025\semester 3\PROYEK 2\pancong\resources\views/layouts/nav.blade.php ENDPATH**/ ?>