<div class="footer text-center">
  <div class="grid1">
      <div class="row">
        <div class="col a">
            <h3>Contact</h3>
            <a href="#" class="bi bi-geo-alt-fill"> Jl. Jend. Sudirman, Karanganyar,
                Kec. Indramayu,  Kabupaten Indramayu,
                Jawa Barat 45213</a>
            <a href="#" class="bi bi-telephone-plus-fill"> (+62) 899-6666-599</a>
            <a href="#" class="bi bi-envelope-fill"> PamerIndramayu@gmail.com</a>
        </div>
        <div class="col b">
          <h3>Follow Us</h3>
          <a href="" class="bi bi-instagram"></a>
          <a href="" class="bi bi-facebook"></a>
          <a href="" class="bi bi-twitter-x"></a>
          <a href="" class="bi bi-google"></a>
        </div>
      </div>
    </div>
    <div class="grid2">
      <p><i class="bi bi-c-circle">Copyright2023-FOP</i></p>
    </div>
</div>
<?php /**PATH C:\Users\ninas\OneDrive\Documents\KULIAH 2022-2025\semester 3\PROYEK 2\pancong\resources\views/pamer/footer.blade.php ENDPATH**/ ?>