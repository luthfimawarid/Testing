@extends('admin.dashboard.main')

@section('content')

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h3>Tambah Menu</h3>
        </div>
        <div class="pull-right" style="margin-bottom:10px;">
        <a class="btn btn-success" href="#">New Menu</a>
        </div>
    </div>
</div>
@endsection