<header class="navbar sticky-top bg-warning flex-md-nowrap p-0 shadow" data-bs-theme="warning">
    <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-10 text-white fst-italic" href="#">FlavourOfPamer</a>
  </header>