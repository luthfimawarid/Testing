@extends('admin.dashboard.main')

@section('content')
    <canvas id="bar-chart-custom-tooltip"></canvas>
    <script src="js/harian.js"></script>
@endsection