@extends('layouts.main')
@section('title', $title)
@section('content')
    <h1>{{ $konten }}</h1>
    
@endsection